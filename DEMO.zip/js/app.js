/* ============================================================
   SISTEMA DE CARPINTERÍA — TALLER DEL ROBLE COLOMBIANO
   Archivo: js/app.js
   Descripción: Utilidades globales reutilizadas en todas las páginas
   ============================================================ */

'use strict';

/* ── CONSTANTES ─────────────────────────────────────────── */
const SESSION_KEY   = 'trc_user';
const TIMEOUT_MS    = 30 * 60 * 1000;
const TIMEOUT_PAGE  = 'sesion-expirada.html';

/* ── GESTIÓN DE SESIÓN ──────────────────────────────────── */
const Session = {
  get()        { try { return JSON.parse(sessionStorage.getItem(SESSION_KEY)); } catch { return null; } },
  set(data)    { sessionStorage.setItem(SESSION_KEY, JSON.stringify(data)); },
  clear()      { sessionStorage.removeItem(SESSION_KEY); },
  isActive()   { return !!this.get(); },
  getRole()    { const u = this.get(); return u ? u.rol : null; },
  getName()    { const u = this.get(); return u ? u.nombre : ''; },
  getInitials(){ const n = this.getName(); return n.split(' ').map(p=>p[0]).slice(0,2).join('').toUpperCase(); }
};

/* ── TEMPORIZADOR DE INACTIVIDAD (RF11 / RNF) ───────────── */
let _timer = null;

function resetInactivityTimer() {
  clearTimeout(_timer);
  _timer = setTimeout(() => {
    Session.clear();
    window.location.href = TIMEOUT_PAGE;
  }, TIMEOUT_MS);
}

function initInactivityTimer() {
  if (!Session.isActive()) return;
  ['mousemove','keydown','click','scroll','touchstart'].forEach(ev =>
    document.addEventListener(ev, resetInactivityTimer, { passive: true })
  );
  resetInactivityTimer();
}

/* ── POBLAR NAVBAR CON DATOS DE SESIÓN ──────────────────── */
function populateNavUser() {
  const user = Session.get();
  if (!user) return;
  const avatarEl = document.querySelector('.nav-avatar');
  const nameEl   = document.querySelector('.nav-name');
  const badgeEl  = document.querySelector('.badge-rol');
  if (avatarEl) avatarEl.textContent = Session.getInitials();
  if (nameEl)   nameEl.textContent   = user.nombre + ' ' + (user.apellido || '');
  if (badgeEl) {
    badgeEl.textContent = user.rol;
    badgeEl.className   = 'badge-rol ' +
      (user.rol.toLowerCase().includes('admin') ? 'badge-admin' : 'badge-carpintero');
  }
}

/* ── VALIDACIÓN DE FORMULARIOS ───────────────────────────── */
const Validator = {
  validate(el, rules = {}) {
    const val = el.value.trim();
    if (rules.required && val === '') return 'Este campo es obligatorio.';
    if (val === '') return null;
    if (rules.min  !== undefined && parseFloat(val) < rules.min)  return `El valor mínimo es ${rules.min}.`;
    if (rules.max  !== undefined && parseFloat(val) > rules.max)  return `El valor máximo es ${rules.max}.`;
    if (rules.minLen && val.length < rules.minLen) return `Mínimo ${rules.minLen} caracteres.`;
    if (rules.maxLen && val.length > rules.maxLen) return `Máximo ${rules.maxLen} caracteres.`;
    if (rules.pattern && !rules.pattern.test(val)) return rules.patternMsg || 'Formato inválido.';
    if (rules.custom) return rules.custom(val);
    return null;
  },
  showError(el, msg) {
    el.classList.toggle('error', !!msg);
    let errEl = el.parentElement.querySelector('.form-error');
    if (!errEl) {
      errEl = document.createElement('span');
      errEl.className = 'form-error';
      el.insertAdjacentElement('afterend', errEl);
    }
    errEl.style.display = msg ? 'flex' : 'none';
    errEl.innerHTML = msg ? `
      <svg width="13" height="13" viewBox="0 0 16 16" fill="none">
        <circle cx="8" cy="8" r="7" stroke="currentColor" stroke-width="1.5"/>
        <line x1="8" y1="5" x2="8" y2="9" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
        <circle cx="8" cy="11.5" r=".9" fill="currentColor"/>
      </svg>${msg}` : '';
  },
  validateForm(formEl) {
    let valid = true;
    formEl.querySelectorAll('[data-rules]').forEach(el => {
      let rules = {};
      try { rules = JSON.parse(el.dataset.rules); } catch {}
      ['min','max','minLen','maxLen'].forEach(k => { if (rules[k] !== undefined) rules[k] = Number(rules[k]); });
      const msg = this.validate(el, rules);
      this.showError(el, msg);
      if (msg) valid = false;
    });
    return valid;
  }
};

/* ── HELPERS DE UI ───────────────────────────────────────── */
function showFormAlert(containerEl, msg, type = 'error') {
  let alertEl = containerEl.querySelector('.form-global-alert');
  if (!alertEl) {
    alertEl = document.createElement('div');
    alertEl.className = 'form-global-alert';
    containerEl.prepend(alertEl);
  }
  alertEl.innerHTML = msg ? `
    <div class="alert alert-${type}" role="alert">
      <span class="alert-icon">${type === 'error' ? '⚠' : '✓'}</span>
      <div>${msg}</div>
    </div>` : '';
}

function bindConditional(toggleEl, targetEl) {
  function update() {
    const visible = toggleEl.checked;
    targetEl.style.display = visible ? '' : 'none';
    targetEl.querySelectorAll('[data-rules]').forEach(inp => {
      if (!visible) { inp.value = ''; Validator.showError(inp, null); }
    });
  }
  toggleEl.addEventListener('change', update);
  update();
}

/* ── STEPPER HELPER ──────────────────────────────────────── */
function updateStepper(stepperEl, currentStep) {
  stepperEl.querySelectorAll('.step-item').forEach((item, i) => {
    item.classList.remove('active', 'done');
    if (i + 1 === currentStep) item.classList.add('active');
    if (i + 1 <  currentStep) item.classList.add('done');
  });
  stepperEl.querySelectorAll('.step-line').forEach((line, i) => {
    line.classList.toggle('done', i + 1 < currentStep);
  });
}

/* ── INICIALIZACIÓN GENERAL ──────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  populateNavUser();
  initInactivityTimer();

  document.querySelectorAll('#btn-cerrar-sesion, .js-cerrar-sesion').forEach(btn => {
    btn.addEventListener('click', e => {
      e.preventDefault();
      Session.clear();
      window.location.href = 'index.html';
    });
  });

  document.querySelectorAll('.model-card').forEach(card => {
    card.addEventListener('click', () => {
      card.closest('.model-grid').querySelectorAll('.model-card')
        .forEach(c => c.classList.remove('selected'));
      card.classList.add('selected');
      const input = document.getElementById('tipo-modelo');
      if (input) input.value = card.dataset.value || card.querySelector('.model-name')?.textContent || '';
    });
  });

  document.querySelectorAll('.animate-in').forEach((el, i) => {
    el.style.animationDelay = (i * 0.06) + 's';
  });
});